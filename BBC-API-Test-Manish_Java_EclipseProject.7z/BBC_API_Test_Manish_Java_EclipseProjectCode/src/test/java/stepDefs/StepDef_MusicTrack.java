/**
 * 
 */
package stepDefs;

import java.net.MalformedURLException;
import org.testng.Assert;
import org.testng.log4testng.Logger;
import APIPages.MusicApiPg;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

/**
 * Music Track step definition file for both the features SoundTrack Scenarios 1 & 2 and SoundTrack Scenarios 3,4 & 5.features 
 *
 */
public class StepDef_MusicTrack {
	/*
	 * Class level variable defined
	 */
	private Response lresponse = Hooks.response;
	private JsonPath extractedResponseLcl = Hooks.extractResponseJSN;;
	private MusicApiPg musilAPIPagObj = new MusicApiPg(lresponse, extractedResponseLcl);
	private Logger logger = Logger.getLogger(StepDef_MusicTrack.class);
	
	/*
	 * Given condition as background for all the five scenarios
	 */
	@Given("^Get request is sent to Music Track API$")
	public void get_request_is_sent_to_music_track_api() throws MalformedURLException {
		System.out.println("Server Details :: " + musilAPIPagObj.getserverDetails());
		Assert.assertNotNull(musilAPIPagObj.getserverDetails());
	}

	/*
	 * When condition as background for all the five scenarios
	 */
	@When("^I extract the response$")
	public void i_extract_the_response() {
		Assert.assertNotNull(musilAPIPagObj.extractResponseAsJson());
	}

	/*
	 * Scenario1 then condition verifying response code
	 */
	@Then("HTTP status code of the response is {int}")
	public void http_status_code_of_the_response_is(int expectedStatusCode) {
		System.out.println("Actual Status Code is ::" + musilAPIPagObj.getStatusCode());
		Assert.assertEquals(musilAPIPagObj.getStatusCode(), expectedStatusCode);
	}

	/*
	 * Scenario1 then condition verifying response times
	 */
	@Then("the response time of the request is below {int} milliseconds")
	public void the_response_time_of_the_request_is_below_milliseconds(double expectedResponseTime)
	{
		System.out.println("Actual Response Time is ::" + musilAPIPagObj.getResponseTime());
		Assert.assertTrue(musilAPIPagObj.getResponseTime() < expectedResponseTime);
	}

	/*
	 * Scenario2 verifying then condition the total count of ID items
	 */
	@Then("total {int} items present in the id data array")
	public void total_items_present_in_the_id_data_array(int expectedTotalItemInIDField) {
		System.out.println ("ID field count is :: " + musilAPIPagObj.getIDItemsCount());
		Assert.assertEquals(musilAPIPagObj.getIDItemsCount(), expectedTotalItemInIDField);
	}

	/*
	 * Scenario2 verifying then condition the null and of empty values for ID items
	 */
	@Then("the id field is never returned null or empty for all the items in data array")
	public void the_id_field_is_never_returned_null_or_empty_for_all_the_items_in_data_array() {
		System.out.println("ID field values are :: " + extractedResponseLcl.getString("data.id"));
		for (int i = 0; i < extractedResponseLcl.getInt("data.id.size()"); i++) {
			Assert.assertNotNull(extractedResponseLcl.getString("data.id[" + i + "]"));
			Assert.assertTrue(!extractedResponseLcl.getString("data.id[" + i + "]").isEmpty());
		}
	}

	/*
	 * Scenario2 verifying second then condition, segment_type field for every track is always music
	 */
	@Then("the segment_type field for every track is always {string}")
	public void the_segment_type_field_for_every_track_is_always(String expectedSegmentType) {
		System.out.println("segment_type field count is :: " + extractedResponseLcl.getInt("data.segment_type.size()"));
		System.out.println("segment_type field values are :: " + extractedResponseLcl.getString("data.segment_type"));

		for (int i = 0; i < extractedResponseLcl.getInt("data.segment_type.size()"); i++) {
			Assert.assertEquals(extractedResponseLcl.getString("data.segment_type[" + i + "]"), expectedSegmentType);
		}
	}
	
	/*
	 * Scenario3 verifying then condition, the primary field in title_list is never returned null or empty for any track
	 */
	@Then("the primary field in title_list is never returned null or empty for any track")
	public void the_primary_field_in_title_list_is_never_returned_null_or_empty_for_any_track() 
	{
		logger.info("is primary_field_in_title_list_null_or_empt? :: "  + musilAPIPagObj.the_primary_field_in_title_list_is_never_null_or_empty());
		Assert.assertTrue(musilAPIPagObj.the_primary_field_in_title_list_is_never_null_or_empty());
	}

	/*
	 * Scenario4 verifying then condition, only 1 track in the list has now_playing field in offset as true
	 */
	@Then("only {int} track in the list has now_playing field in offset as true")
	public void only_track_in_the_list_has_now_playing_field_in_offset_as_true(int expectOne)
	{
		logger.info("Now Playing field ofset as true count is :: "  + musilAPIPagObj.now_playing_field_in_offset_as_true());
		Assert.assertEquals(musilAPIPagObj.now_playing_field_in_offset_as_true(),expectOne);
	}

	/*
	 * Scenario5 verifying then condition, In the response headers has the Date value
	 */
	@Then("In the response headers has the Date value")
	public void in_the_response_headers_has_the_date_value()
	{	
		System.out.println("Header values are ::" + musilAPIPagObj.headers_has_the_date_value());
		Assert.assertNotNull(musilAPIPagObj.headers_has_the_date_value());
	}
}
