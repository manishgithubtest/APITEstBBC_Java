package stepDefs;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import utility.PropertiesFileReader;

import static io.restassured.RestAssured.*;

public class Hooks {

	public static Response response;
	public static JsonPath extractResponseJSN;
	public PropertiesFileReader propertiesReader = new PropertiesFileReader();
	
	/*
	 */

	@Before
	public void runTest() throws Exception
	{
		response = given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON).when()
				.get(new URL(propertiesReader.getValue("BASE_URL"))).then().contentType(ContentType.JSON).extract().response();
		
		extractResponseJSN = new JsonPath(response.asString());
    }
}