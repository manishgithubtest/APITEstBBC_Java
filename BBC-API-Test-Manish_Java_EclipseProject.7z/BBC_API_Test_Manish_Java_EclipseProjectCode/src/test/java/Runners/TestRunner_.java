/**
 * 
 */
package Runners;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

/**
 * @author gupta
 *
 */

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/features" }, glue = { "stepDefs" }, 
plugin = { 
		"pretty",
		"json:target/cucumber.json",
		"html:target/Reports/APIBBCMSS_TestReport.html", 
		"pretty:target/Reports/APIBBCMSS_Text_Report.txt",
		"junit:target/Reports/APIBBCMSS_XML_Reports.xml"
		}, 
tags = "@RegressionTest",
		// tags = "@Smoke",
		dryRun = false, 
		monochrome = true)


public class TestRunner_ {
	
}
