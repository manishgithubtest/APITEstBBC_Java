/**
 * 
 */
package APIPages;

import java.util.concurrent.TimeUnit;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

/**
 * Page class for Music Tack Step def. test class for Page Object Model framework
 *
 */
public class MusicApiPg {
	
	private Response lResponse;
	private JsonPath extractedResponseJSNlocal; 

	/*
	 *  MusicApiPg Constructor
	 */
	public MusicApiPg(Response reponse, JsonPath extractResponseJSN)
	{
		this.lResponse = reponse;
		this.extractedResponseJSNlocal = extractResponseJSN;
	}
	
	/*
	 * Get Server details for Music Track StepDef class
	 */
	public String getserverDetails()
	{
		String serverDetials= lResponse.getHeaders().getValue("server");
		return serverDetials;
	}

	/*
	 * extract JSon response details for Music Track StepDef class
	 */
	public JsonPath extractResponseAsJson()
	{
		return extractedResponseJSNlocal;
	}
	
	/*
	 * Get status code for Music Track StepDef class
	 */
	public int getStatusCode()
	{
		int actualResponseCode= lResponse.then().extract().statusCode();
		return actualResponseCode;
	}
	
	/*
	 * Get response time for Music Track StepDef class
	 */
	public double getResponseTime()
	{
		double actualResponseTime = lResponse.getTimeIn(TimeUnit.MILLISECONDS);
		return actualResponseTime;
	}
	
	/*
	 * Get ID items count for Music Track StepDef class
	 */
	public int getIDItemsCount()
	{
		int actualIDItemsCount= extractedResponseJSNlocal.getInt("data.id.size()");
		return actualIDItemsCount;
	}

	/*
	 * the_primary_field_in_title_list_is_never_returned_null_or_empty_for_any_track
	 */
	public Boolean the_primary_field_in_title_list_is_never_null_or_empty()
	{
		Boolean notNullEmptyFlag = true; 
		System.out.println("Count of Primary field values in title_list is :: " + extractedResponseJSNlocal.getInt("data.title_list.primary.size()"));
		System.out.println("Primary field values in title_list are :: " + extractedResponseJSNlocal.getString("data.title_list.primary"));
		for (int i = 0; i < extractedResponseJSNlocal.getInt("data.title_list.primary.size()"); i++) {
			
			if ((extractedResponseJSNlocal.getString("data.title_list.primary[" + i + "]").equals(null)) || (extractedResponseJSNlocal.getString("data.title_list.primary[" + i + "]").equals("")))
			{
				System.out.println("Primary field values found null/empty :: " + extractedResponseJSNlocal.getString("data.title_list.primary[" + i + "]"));
				notNullEmptyFlag = false;
			}
		}
		return notNullEmptyFlag;
	}
	
	/*
	 * only_track_in_the_list_has_now_playing_field_in_offset_as_true
	 */
	public int now_playing_field_in_offset_as_true()
	{
		int actualOffsetTrueCount =0;
		System.out.println("Count of now_playing offset values is :: " + extractedResponseJSNlocal.getInt("data.offset.now_playing.size()"));
		System.out.println("now_playing offset values are :: " + extractedResponseJSNlocal.getString("data.offset.now_playing"));
		for (int i = 0; i < extractedResponseJSNlocal.getInt("data.offset.now_playing.size()"); i++)
		{	
			if (extractedResponseJSNlocal.getBoolean("data.offset.now_playing[" + i + "]"))
			{
				System.out.println("Primary field values found null/empty :: " + extractedResponseJSNlocal.getString("data.offset.now_playing[" + i + "]"));
				actualOffsetTrueCount++;
			}
		}
		System.out.println("Count of now_playing offset found as True is :: " + actualOffsetTrueCount);
		return actualOffsetTrueCount;
	}
	
	/*
	 * response_headers_has_the_date_value
	 */
	
	public String headers_has_the_date_value()
	{
		String actualResponseCode = lResponse.getHeaders().getValue("Date");
		/*
		 * SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd MMMM");
		 * dateFormat.setLenient(false);
		 * 
		 * try { dateFormat.parse(actualResponseCode.trim()); } catch
		 * (java.text.ParseException e) { Boolean headerDateValueFlag = false;
		 * e.printStackTrace();
		 * 
		 * }
		 */
		return actualResponseCode;
	}
}
